# PhotoSorter — Versión inicial

App que clasifica automáticamente tus fotos en 2 carpetas: **Cabello** y **Uñas**.

## Qué hace esta versión inicial

- Al tomar una foto con la cámara, la app la analiza automáticamente (sin internet)
  y, si reconoce cabello o uñas con suficiente confianza, la mueve sola a la carpeta
  correspondiente dentro de tu galería:
  - `Pictures/Cabello`
  - `Pictures/Uñas`
- Si no está segura, deja la foto en la pestaña **"Sin clasificar"** para que la
  muevas tú manualmente con un botón.
- Usa un modelo genérico de reconocimiento de imágenes (Google ML Kit). Es una
  primera versión: identifica bien "cabello" vs "uñas" en general, pero **no**
  distingue todavía entre balayage, corte, tinte, etc. Eso se puede afinar en una
  siguiente versión con un modelo entrenado específicamente con tus fotos.

## Cómo subir el código a GitHub desde el navegador del celular

1. Entra a [github.com](https://github.com) e inicia sesión (o crea una cuenta gratis).
2. Toca el ícono **+** arriba y elige **"New repository"**.
3. Ponle un nombre, por ejemplo `photosorter-app`, márcalo como **Public** o **Private**
   (cualquiera funciona), y toca **"Create repository"**.
4. Dentro del repositorio recién creado, busca el botón **"Add file"** → **"Upload files"**.
5. Selecciona **todos los archivos y carpetas** de este proyecto (idealmente
   arrastrándolos o seleccionando la carpeta completa; si tu navegador no te deja
   subir carpetas, sube los archivos manteniendo la misma estructura de carpetas
   que ves aquí, creando las carpetas con el botón "Create new file" y escribiendo
   la ruta completa, por ejemplo `app/src/main/java/com/photosorter/app/MainActivity.kt`).
6. Toca **"Commit changes"**.
7. Ve a la pestaña **"Actions"** del repositorio. Debería aparecer un proceso llamado
   **"Compilar APK"** ejecutándose automáticamente (tarda unos 3-5 minutos).
8. Cuando termine (ícono verde ✅), entra a esa ejecución y baja hasta
   **"Artifacts"** → descarga **`PhotoSorter-apk`**. Es un archivo .zip que contiene
   el .apk.
9. Descomprime el .zip en tu celular (los administradores de archivos de Android
   suelen tener la opción de "Extraer"), y toca el archivo `.apk` para instalarlo.
   Es posible que Android te pida activar **"Instalar apps de fuentes desconocidas"**
   la primera vez.

## Permisos que pedirá la app

- Acceso a fotos (para leer y organizar tus imágenes).
- Notificaciones (para mostrar el aviso de que el servicio está activo).

## Próximos pasos (versión 2)

- Entrenar un modelo propio con fotos reales del salón para reconocer categorías
  específicas (balayage, tinte, manicure, uñas acrílicas, etc.).
- Agregar la opción de deshacer un movimiento.
- Mejorar el ícono y diseño visual de la app.
