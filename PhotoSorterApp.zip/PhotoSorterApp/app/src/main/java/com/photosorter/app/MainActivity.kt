package com.photosorter.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.tabs.TabLayout
import com.photosorter.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: PhotoAdapter
    private var serviceRunning = false
    private var currentTab = 0 // 0 = pendientes, 1 = cabello, 2 = uñas

    private val permissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            startPhotoService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = PhotoAdapter(
            context = this,
            items = emptyList(),
            showActions = true,
            onMoveHair = { item -> movePhoto(item.id, FileOrganizer.FOLDER_HAIR) },
            onMoveNails = { item -> movePhoto(item.id, FileOrganizer.FOLDER_NAILS) }
        )
        binding.recyclerView.layoutManager = GridLayoutManager(this, 2)
        binding.recyclerView.adapter = adapter

        binding.btnToggleService.setOnClickListener {
            if (serviceRunning) stopPhotoService() else requestPermissionsAndStart()
        }

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                currentTab = tab.position
                loadPhotos()
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        loadPhotos()
    }

    override fun onResume() {
        super.onResume()
        loadPhotos()
    }

    private fun requestPermissionsAndStart() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val needed = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isEmpty()) {
            startPhotoService()
        } else {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    private fun startPhotoService() {
        ContextCompat.startForegroundService(this, Intent(this, PhotoWatcherService::class.java))
        serviceRunning = true
        binding.btnToggleService.setText(R.string.stop_service)
    }

    private fun stopPhotoService() {
        stopService(Intent(this, PhotoWatcherService::class.java))
        serviceRunning = false
        binding.btnToggleService.setText(R.string.start_service)
    }

    /** Carga las fotos según la pestaña activa, consultando directamente MediaStore. */
    private fun loadPhotos() {
        val selection: String
        val args: Array<String>
        when (currentTab) {
            1 -> {
                selection = "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?"
                args = arrayOf("%${FileOrganizer.FOLDER_HAIR}%")
            }
            2 -> {
                selection = "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?"
                args = arrayOf("%${FileOrganizer.FOLDER_NAILS}%")
            }
            else -> {
                // Pendientes: fotos de la cámara que todavía no fueron movidas
                selection = "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ? AND " +
                        "${MediaStore.Images.Media.RELATIVE_PATH} NOT LIKE ? AND " +
                        "${MediaStore.Images.Media.RELATIVE_PATH} NOT LIKE ?"
                args = arrayOf("%DCIM/Camera%", "%${FileOrganizer.FOLDER_HAIR}%", "%${FileOrganizer.FOLDER_NAILS}%")
            }
        }

        val projection = arrayOf(MediaStore.Images.Media._ID)
        val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"
        val items = mutableListOf<PhotoItem>()

        contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, args, sortOrder
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            while (cursor.moveToNext()) {
                items.add(PhotoItem(cursor.getLong(idCol)))
            }
        }

        adapter.updateItems(items)
        binding.txtEmpty.visibility = if (items.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun movePhoto(id: Long, folder: String) {
        FileOrganizer.moveImage(this, id, folder)
        loadPhotos()
    }
}
