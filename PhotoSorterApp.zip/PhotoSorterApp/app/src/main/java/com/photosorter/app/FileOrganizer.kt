package com.photosorter.app

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore

/**
 * Se encarga de "mover" fotos entre carpetas dentro del almacenamiento del teléfono.
 * En Android 10+ (nuestro mínimo) no se puede mover archivos directamente por el
 * sistema de "scoped storage", así que actualizamos la ruta a través de MediaStore.
 */
object FileOrganizer {

    const val FOLDER_HAIR = "Pictures/Cabello"
    const val FOLDER_NAILS = "Pictures/Uñas"

    /**
     * Mueve la foto identificada por [imageId] a la carpeta indicada en [targetFolder].
     * Devuelve true si el movimiento fue exitoso.
     */
    fun moveImage(context: Context, imageId: Long, targetFolder: String): Boolean {
        val uri = ContentUris.withAppendedId(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, imageId
        )
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.RELATIVE_PATH, targetFolder)
        }
        return try {
            val rows = context.contentResolver.update(uri, values, null, null)
            rows > 0
        } catch (e: Exception) {
            false
        }
    }

    fun uriForId(imageId: Long): Uri {
        return ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, imageId)
    }
}
