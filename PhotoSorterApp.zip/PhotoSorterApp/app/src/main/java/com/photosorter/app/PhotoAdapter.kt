package com.photosorter.app

import android.content.Context
import android.util.Size
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.photosorter.app.databinding.ItemPhotoBinding

data class PhotoItem(val id: Long)

class PhotoAdapter(
    private val context: Context,
    private var items: List<PhotoItem>,
    private val showActions: Boolean,
    private val onMoveHair: (PhotoItem) -> Unit,
    private val onMoveNails: (PhotoItem) -> Unit
) : RecyclerView.Adapter<PhotoAdapter.PhotoViewHolder>() {

    fun updateItems(newItems: List<PhotoItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PhotoViewHolder {
        val binding = ItemPhotoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PhotoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PhotoViewHolder, position: Int) {
        val item = items[position]
        val uri = FileOrganizer.uriForId(item.id)
        try {
            val thumb = context.contentResolver.loadThumbnail(uri, Size(300, 300), null)
            holder.binding.imgThumb.setImageBitmap(thumb)
        } catch (e: Exception) {
            holder.binding.imgThumb.setImageDrawable(null)
        }

        holder.binding.layoutActions.visibility = if (showActions) android.view.View.VISIBLE else android.view.View.GONE
        holder.binding.btnMoveHair.setOnClickListener { onMoveHair(item) }
        holder.binding.btnMoveNails.setOnClickListener { onMoveNails(item) }
    }

    override fun getItemCount(): Int = items.size

    class PhotoViewHolder(val binding: ItemPhotoBinding) : RecyclerView.ViewHolder(binding.root)
}
