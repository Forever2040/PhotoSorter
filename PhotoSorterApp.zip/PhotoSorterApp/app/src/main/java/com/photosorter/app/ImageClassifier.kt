package com.photosorter.app

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.tasks.await

enum class Category { HAIR, NAILS, UNKNOWN }

/**
 * Clasificador basado en el modelo genérico de ML Kit (funciona sin conexión
 * a internet, corre en el propio teléfono). Es una PRIMERA VERSIÓN: revisa
 * las etiquetas que detecta el modelo y busca palabras relacionadas con
 * cabello o uñas. Más adelante se puede reemplazar por un modelo propio
 * entrenado con fotos del salón para mayor precisión.
 */
object ImageClassifier {

    private val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)

    private val hairKeywords = listOf(
        "hair", "hairstyle", "hairdressing", "wig", "hairstyling",
        "hair coloring", "afro", "bangs", "hair care"
    )

    private val nailKeywords = listOf(
        "nail", "manicure", "pedicure", "nail polish", "finger", "nail care"
    )

    suspend fun classify(bitmap: Bitmap): Category {
        val image = InputImage.fromBitmap(bitmap, 0)
        return try {
            val labels = labeler.process(image).await()
            var hairScore = 0f
            var nailScore = 0f
            for (label in labels) {
                val text = label.text.lowercase()
                if (hairKeywords.any { text.contains(it) }) hairScore += label.confidence
                if (nailKeywords.any { text.contains(it) }) nailScore += label.confidence
            }
            when {
                hairScore == 0f && nailScore == 0f -> Category.UNKNOWN
                hairScore >= nailScore -> Category.HAIR
                else -> Category.NAILS
            }
        } catch (e: Exception) {
            Category.UNKNOWN
        }
    }
}
