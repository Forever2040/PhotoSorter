package com.photosorter.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.database.ContentObserver
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Servicio que vigila la carpeta de la cámara (DCIM/Camera). Cada vez que
 * detecta una foto nueva, la clasifica automáticamente como Cabello o Uñas
 * usando ImageClassifier y la mueve con FileOrganizer.
 *
 * Si no logra clasificarla con confianza, la deja donde está para que el
 * usuario la mueva manualmente desde la app (pestaña "Sin clasificar").
 */
class PhotoWatcherService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO)
    private lateinit var observer: ContentObserver
    private val prefs by lazy { getSharedPreferences("photosorter_prefs", MODE_PRIVATE) }

    companion object {
        const val CHANNEL_ID = "photosorter_channel"
        const val NOTIF_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification())

        observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean, uri: Uri?) {
                super.onChange(selfChange, uri)
                scope.launch { checkForNewPhoto() }
            }
        }
        contentResolver.registerContentObserver(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, observer
        )

        // Revisamos también apenas arranca el servicio, por si ya hay fotos pendientes.
        scope.launch { checkForNewPhoto() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        contentResolver.unregisterContentObserver(observer)
    }

    private suspend fun checkForNewPhoto() {
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.RELATIVE_PATH
        )
        // Solo miramos fotos que vengan de la carpeta de la cámara (no de otras apps).
        val selection = "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?"
        val selectionArgs = arrayOf("%DCIM/Camera%")
        val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC LIMIT 5"

        contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            projection, selection, selectionArgs, sortOrder
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val key = "processed_$id"
                if (prefs.getBoolean(key, false)) continue

                // Marcamos como procesada de inmediato para no reprocesarla en bucle
                // cuando la movamos (eso también dispara onChange).
                prefs.edit().putBoolean(key, true).apply()
                processPhoto(id)
            }
        }
    }

    private fun processPhoto(imageId: Long) {
        try {
            val uri = FileOrganizer.uriForId(imageId)
            val input = contentResolver.openInputStream(uri) ?: return

            val options = BitmapFactory.Options().apply { inSampleSize = 4 }
            val bitmap = BitmapFactory.decodeStream(input, null, options)
            input.close()
            if (bitmap == null) return

            scope.launch {
                val category = ImageClassifier.classify(bitmap)
                val folder = when (category) {
                    Category.HAIR -> FileOrganizer.FOLDER_HAIR
                    Category.NAILS -> FileOrganizer.FOLDER_NAILS
                    Category.UNKNOWN -> null
                }
                if (folder != null) {
                    FileOrganizer.moveImage(this@PhotoWatcherService, imageId, folder)
                }
                // Si es UNKNOWN, no la movemos: queda visible en "Sin clasificar"
                // dentro de la app para que el usuario decida manualmente.
            }
        } catch (e: Exception) {
            // Si algo falla, simplemente dejamos la foto sin clasificar.
        }
    }

    private fun buildNotification(): android.app.Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_MIN
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .build()
    }
}
